//Name-Tanuj 
//Batch- 1A82(2025-2029)
//Roll number-1025170194
#include <stdio.h>   
int main()
    {
        int roll_number = 1025170194;
    char char_name[5]="Tanuj";
    float a;
    printf("enter the number : ");
    scanf("%f",&a);
    printf("you entered number : %f\n",a);

    return 0;
}
    

   