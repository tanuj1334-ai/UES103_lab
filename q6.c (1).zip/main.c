//Name-Tanuj 
//Batch- 1A82(2025-2029)
//Roll number-1025170194

int main() {
    int roll_number = 1025170194;
    char char_name[5]="Tanuj";
    int a;
    printf("enter the number : ");
    scanf("%d",&a);
    printf("you entered number : %d\n",a);

    return 0;
}