//Name-Tanuj
//Batch- 1A82(2025-2029)
//Roll number-1025170194
#include <stdio.h>

int main()
{
    int roll_number =1025170194;
    char char_name[5]="Tanuj";
    float a,b,c;
    printf("enter a number : ");
    scanf("%f",&a);
    printf("enter a number : ");
    scanf("%f",&b);
    c = a/b;
    printf(" your number is :%f\n",c);

    return 0;
}