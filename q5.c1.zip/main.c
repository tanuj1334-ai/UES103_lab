//Name-Tanuj 
//Batch- 1A82(2025-2029)
//Roll number-1025030194
#include <stdio.h>
int main()
{
    int roll_number=1025030194;
    char char_name[5]="Tanuj";

    printf("Hello World");

    return 0;
}
